/*
** EPITECH PROJECT, 2019
** MY_SORT_IN_ARRAY
** File description:
** sort in array
*/

#include "../inc/my.h"

void my_sort_int_array(int *tab, int size)
{
}
