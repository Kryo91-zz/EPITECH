/*
** EPITECH PROJECT, 2019
** MY_SHOWMEM
** File description:
** print a memory dump
*/

#include "../inc/my.h"

int my_showmem(char const *str, int size)
{
    return (0);
}
