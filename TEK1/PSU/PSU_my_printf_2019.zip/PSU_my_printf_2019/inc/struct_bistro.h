/*
** EPITECH PROJECT, 2019
** error
** File description:
** Struct
*/

typedef struct argument_s
{
    char *delimiter;
    char *str;
    char **result;
} argument_t;
